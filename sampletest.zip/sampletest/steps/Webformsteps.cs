﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestStack.White;
using TestStack.White.UIItems;
using TestStack.White.UIItems.WindowItems;
using TestStack.White.UIItems.Finders;
using System.Collections.Generic;
using TestStack.White.Factory;
using TestStack.White.UIItems.ListBoxItems;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System.Configuration;
using OpenQA.Selenium.Support;



namespace sampletest.steps
{
    [Binding]
    class Webformsteps
    {

        public static IWebDriver driver;
        //[Obsolete]
  

        [Given(@"I have Launched the Webform in Chrome browser")]
        public void GivenIHaveLaunchedTheWebformInChromeBrowser()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://qa-recruitment-form.s3-website-eu-west-1.amazonaws.com/#/");

        }
     [Given(@"I wait for ""(.*)"" second")]
        public void GivenIWaitForSecond(int seconds)
        {
            Thread.Sleep(TimeSpan.FromSeconds(seconds));

        }

        [Then(@"I quite the Browser")]
        public void ThenIQuiteTheBrowser()
        {
            driver.Quit();
        }
        [When(@"I fill the form with correct details")]
        public void WhenIFillTheFormWithCorrectDetails()
        {
            driver.FindElement(By.Id("formNameInput")).SendKeys("Anilkumar");
            driver.FindElement(By.Id("formEmailInput")).SendKeys("anilcse.107@gmail.com");
            driver.FindElement(By.XPath("//input[@class = 'form-control' and @type = 'number']")).SendKeys("3");
            //driver.FindElement(By.XPath("//select[@id='formRoleSelect']")).Click();
            //var options = driver.FindElements(By.TagName("option"));
            OpenQA.Selenium.Support.UI.SelectElement oSelect = new OpenQA.Selenium.Support.UI.SelectElement(driver.FindElement(By.XPath("//select[@id='formRoleSelect']")));
            oSelect.SelectByText("Frontend Developer");
            driver.FindElement(By.Id("formAboutYouTextArea")).SendKeys("I am good at Automation");
            driver.FindElement(By.Id("formTermsAndConditionsCheckbox")).Click();
                       
        }

        [When(@"I click on Submit button")]
        public void WhenIClickOnSubmitButton()
        {
            driver.FindElement(By.Id("formSubmitButton")).Click();
            Thread.Sleep(TimeSpan.FromSeconds(5));
        }

        [Then(@"I should able to see the SuccessMessage on the  screen")]
        public void ThenIShouldAbleToSeeTheSuccessMessageOnTheScreen(Table table)
        {
            Thread.Sleep(200);
            var successmsg = driver.FindElement(By.XPath("//*[@id='root']/div/h1")).GetAttribute("innerHTML");
            foreach (var row in table.Rows)
            {
                foreach (var c in row)
                {
                    Assert.IsTrue(successmsg.Trim().Contains(c.Value));
                }
            }
        }


        [Given(@"I validate the Name field")]
        public void GivenIValidateTheNameField()
        {
            driver.FindElement(By.Id("formNameInput")).SendKeys("A");

        }
        [Then(@"I can able to see the validation warning message  for FullName")]
        public void ThenICanAbleToSeeTheValidationWarningMessageForFullName(Table table)
        {
            var warningmsg = driver.FindElement(By.XPath("//*[@id='root']/div/form/div[1]/div/span[2]")).GetAttribute("innerHTML");
            Thread.Sleep(200);
            //var successmsg = driver.FindElement(By.XPath("//*[@id='root']/div/h1")).GetAttribute("innerHTML");
            foreach (var row in table.Rows)
            {
                foreach (var c in row)
                {
                    Assert.IsTrue(warningmsg.Trim().Contains(c.Value));
                }
            }
        }

        [Given(@"I validate the Email")]
         public void GivenIValidateTheEmail()
        {
            driver.FindElement(By.Id("formEmailInput")).SendKeys("123@");
        }

        [Then(@"I can able to see the validation warning message for Email field")]
        public void ThenICanAbleToSeeTheValidationWarningMessageForEmailField(Table table)
        {
            var warnmessage = driver.FindElement(By.XPath("//*[@id='root']/div/form/div[2]/div/span[2]")).GetAttribute("innerHTML");
            Thread.Sleep(200);
            foreach (var row in table.Rows)
            {
                foreach (var c in row)
                {
                    Assert.IsTrue(warnmessage.Trim().Contains(c.Value));
                }
            }

        }

        [Given(@"I validate the Experience in years")]
        public void GivenIValidateTheExperienceInYears()
        {
            driver.FindElement(By.XPath("//input[@class = 'form-control' and @type = 'number']")).SendKeys("-1");

        }

        [Then(@"I can able to see the Validation warning message for Experince field")]
        public void ThenICanAbleToSeeTheValidationWarningMessageForExperinceField(Table table)
        {
            var warnmessage = driver.FindElement(By.XPath("//*[@id='root']/div/form/div[3]/div/span[2]")).GetAttribute("innerHTML");
            Thread.Sleep(200);
            foreach (var row in table.Rows)
            {
                foreach (var c in row)
                {
                    Assert.IsTrue(warnmessage.Trim().Contains(c.Value));
                }
            }

        }

        [Given(@"I validate the Role field")]
        public void GivenIValidateTheRoleField()
        {
            driver.FindElement(By.Id("formSubmitButton")).Click();
            Thread.Sleep(TimeSpan.FromSeconds(5));
        }

        [Then(@"I can able to see the Validation warning  message for Role field")]
        public void ThenICanAbleToSeeTheValidationWarningMessageForRoleField(Table table)
        {
            var warnmessage = driver.FindElement(By.XPath("//*[@id='root']/div/form/div[4]/div/span[2]")).GetAttribute("innerHTML");
            Thread.Sleep(200);
            foreach (var row in table.Rows)
            {
                foreach (var c in row)
                {
                    Assert.IsTrue(warnmessage.Trim().Contains(c.Value));
                }
            }
        }

        [Given(@"I validate the Checkbox for terms and conditions")]
        public void GivenIValidateTheCheckboxForTermsAndConditions(Table table)
        {
            driver.FindElement(By.Id("formSubmitButton")).Click();
            Thread.Sleep(TimeSpan.FromSeconds(3));
            var warnmessage = driver.FindElement(By.XPath("//*[@id='root']/div/form/div[6]/div/span")).GetAttribute("innerHTML");
            Thread.Sleep(200);
            foreach (var row in table.Rows)
            {
                foreach (var c in row)
                {
                    Assert.IsTrue(warnmessage.Trim().Contains(c.Value));
                }
            }
        }

        [Given(@"I Verify the clear button functinality")]
        public void GivenIVerifyTheClearButtonFunctinality()
        {
            driver.FindElement(By.Id("formClearButton")).Click();

        }
        [When(@"I fill the form with Correctdetails Except for experince")]
        public void WhenIFillTheFormWithCorrectdetailsExceptForExperince()
        {
            driver.FindElement(By.Id("formNameInput")).SendKeys("Anilkumar");
            driver.FindElement(By.Id("formEmailInput")).SendKeys("anilcse.107@gmail.com");
            driver.FindElement(By.XPath("//input[@class = 'form-control' and @type = 'number']")).SendKeys("1");
            OpenQA.Selenium.Support.UI.SelectElement oSelect = new OpenQA.Selenium.Support.UI.SelectElement(driver.FindElement(By.XPath("//select[@id='formRoleSelect']")));
            oSelect.SelectByText("Frontend Developer");
            driver.FindElement(By.Id("formAboutYouTextArea")).SendKeys("I am good at Automation");
            driver.FindElement(By.Id("formTermsAndConditionsCheckbox")).Click();
            driver.FindElement(By.Id("formSubmitButton")).Click();
            Thread.Sleep(TimeSpan.FromSeconds(5));
        }
        [Then(@"I should able to see the Error message on the screen")]
        public void ThenIShouldAbleToSeeTheErrorMessageOnTheScreen(Table table)
        {
            var Failuremsg = driver.FindElement(By.XPath("//*[@id='root']/div/h1")).GetAttribute("innerHTML");
            Thread.Sleep(200);
            foreach (var row in table.Rows)
            {
                foreach (var c in row)
                {
                    Assert.IsTrue(Failuremsg.Trim().Contains(c.Value));
                }
            }
        }

        [Given(@"I click on the Logo")]
        public void GivenIClickOnTheLogo()
        {
            driver.FindElement(By.XPath("//*[@id='northmillLogo']")).Click();
            Thread.Sleep(200);
            
        }

       
        [Then(@"I  should Navigate to the Company website and can able to see the message")]
        public void ThenIShouldNavigateToTheCompanyWebsiteAndCanAbleToSeeTheMessage(Table table)
        {
            var msg = driver.FindElement(By.XPath("/html/body/section[1]/div/div/div/h1")).GetAttribute("innerHTML");
            Thread.Sleep(200);
            foreach (var row in table.Rows)
            {
                foreach (var c in row)
                {
                    Assert.IsTrue(msg.Trim().Contains(c.Value));
                }
            }
        }




    }
}
